# TranquilizerPistol (Shadows of Doubt)

Pistola silenciada tranquilizante: o tiro não causa dano nem mata, só faz o cidadão dormir.

## Como funciona

- Usa a **SemiAutomaticPistolSilenced** do jogo como base (todas as pistolas silenciadas viram tranquilizantes).
- Mirar = botão secundário, atirar = botão primário (lógica do mod Guns).
- Em `Patches.cs`, o `Citizen.RecieveDamage` é interceptado: dano zerado, `enableKill = false`, sem alarme automático. Depois do tiro, chama `NewAIController.SetKO(...)` para pôr o cidadão pra dormir.
- Contador de dardos (`DartsRequiredToSleep`) no padrão do LethalActionReborn, zerado quando o cidadão acorda.

## Configuração (BepInEx/config)

`DartsRequiredToSleep`, `SleepDurationSeconds`, `Accuracy`, `DelayBetweenShotsFactor`, `RecoilAmplitude`, `ZoomInOnAimPct`, `IllegalWhenSeen`, `IllegalStatusDurationOnHit`, `AlertSurroundingOnHit`, `GiveWeapon` (teste).

## Compilar

1. Rode o jogo uma vez com BepInEx 6 IL2CPP instalado (gera `BepInEx\interop`).
2. `dotnet build -c Release -p:SODGameDir="<pasta do jogo>"`
3. Copie `bin\Release\net6.0\TranquilizerPistol.dll` para `BepInEx\plugins\`.

Requer o **SOD.Common**. Não use junto com o mod **Guns** original (o plugin se declara incompatível com ele).

## Status

Código **ainda não compilado nem testado no jogo**. Pontos a validar em jogo:

- Unidade de `forcedDuration` no `SetKO` (segundos reais ou tempo de jogo).
- Se o GUID do Guns é mesmo `Guns` (usado em `BepInIncompatibility`).
- Se o item de dardos/munição da pistola silenciada serve ou se vale criar um item próprio.

## Créditos

Veja `THIRD_PARTY_NOTICES.md` (Guns, de Spyraxi, e SODLethalActionReborn/SOD.Common, de Venomaus — ambos MIT).
