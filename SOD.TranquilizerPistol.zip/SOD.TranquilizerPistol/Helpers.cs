using System;
using System.Collections.Generic;
using System.Linq;
using UniverseLib;

namespace TranquilizerPistol;

// Adapted from Guns by Spyraxi (ReveredRedHood), MIT License.
internal static class Helpers
{
    internal static bool IsPlayerHeardByOthers()
    {
        return InterfaceController.Instance.awarenessIcons.Where(x => x.alertProgress > 0.0f).Any();
    }

    internal static bool IsPlayerBeingPursuedByActor(Actor actor)
    {
        return actor != null
            && Player.Instance.persuedProgressLag > 0.0f
            && actor.ai != null
            && actor.ai.persuitTarget == Player.Instance;
    }

    internal static IEnumerable<T> GetPresetInstances<T>() where T : SoCustomComparison
    {
        var type = typeof(T);
        var presetInstances = RuntimeHelper.FindObjectsOfTypeAll(type);
        if (!presetInstances.Any())
        {
            throw new NullReferenceException($"No presets found with type {type.FullName}.");
        }
        return presetInstances
            .DistinctBy(GetPresetKey)
            .Select(x => x.TryCast<T>());
    }

    internal static string GetPresetKey(object obj)
    {
        return $"{obj.GetActualType().FullName}_{GetPresetName(obj)}";
    }

    internal static string GetPresetName(object obj)
    {
        var castObj = obj.TryCast<SoCustomComparison>();
        try
        {
            return castObj.name;
        }
        catch
        {
            var presetName = castObj.presetName;
            if (!string.IsNullOrEmpty(presetName))
            {
                return presetName;
            }
            return castObj.GetPresetName();
        }
    }
}
