using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace TranquilizerPistol;

internal class Patches
{
    // --- From Guns (Spyraxi, MIT): while holding the pistol, mark the draw bark as a threat. ---
    [HarmonyPatch(typeof(FirstPersonItemController), nameof(FirstPersonItemController.FinishedDrawingNewItem))]
    internal class FirstPersonItemController_FinishedDrawingNewItem
    {
        [HarmonyPrefix]
        internal static void Prefix()
        {
            if (Plugin.Instance.IsPlayerHoldingPistol())
            {
                Plugin.Instance.CurrentInteractablePresetHeld.fpsItem.barkTriggerChance = 0.0f;
            }
        }

        [HarmonyPostfix]
        internal static void Postfix()
        {
            Plugin.Instance.CurrentWeaponPrimaryState = WeaponPrimaryState.NotAiming;
            Plugin.Instance.CurrentWeaponSecondaryState = Plugin.Instance.IsPlayerHoldingPistol()
                ? WeaponSecondaryState.NotAiming
                : WeaponSecondaryState.NotEquipped;
        }
    }

    // --- Core of the mod: a dart hit never damages or kills, it puts the citizen to sleep. ---
    [HarmonyPatch(typeof(Citizen), nameof(Citizen.RecieveDamage))]
    internal class Citizen_RecieveDamage
    {
        // Same idea as LethalActionReborn's hit counter (Venomaus, MIT), but counting darts
        // instead of hits-needed-to-kill. Cleared when a citizen wakes up.
        internal static readonly Dictionary<int, int> DartsTaken = new();

        private static bool _isDart;

        [HarmonyPrefix]
        internal static void Prefix(
            Citizen __instance,
            Actor fromWho,
            ref float amount,
            ref bool alertSurrounding,
            ref bool enableKill)
        {
            _isDart = false;

            if (__instance.isPlayer || __instance.isDead) return;
            if (fromWho == null || !fromWho.isPlayer) return;
            if (Plugin.Instance.CurrentWeaponPrimaryState != WeaponPrimaryState.Firing) return;
            if (!Plugin.Instance.IsPlayerHoldingPistol()) return;

            _isDart = true;

            // No damage, no death, no automatic alarm.
            amount = 0f;
            enableKill = false;
            alertSurrounding = Plugin.Instance.Config.AlertSurroundingOnHit;
        }

        [HarmonyPostfix]
        internal static void Postfix(Citizen __instance, Vector3 damagePosition, Vector3 damageDirection)
        {
            if (!_isDart) return;
            _isDart = false;

            if (__instance.isDead || __instance.ai == null || __instance.ai.ko) return;

            DartsTaken.TryGetValue(__instance.humanID, out var darts);
            darts++;
            DartsTaken[__instance.humanID] = darts;

            if (darts < Plugin.Instance.Config.DartsRequiredToSleep) return;

            DartsTaken.Remove(__instance.humanID);

            // NewAIController.SetKO(val, impactPoint, impactDirection, forced, forcedDuration,
            //                       resetInvesigate, forceMultiplier)
            __instance.ai.SetKO(
                true,
                damagePosition,
                damageDirection,
                true,
                Plugin.Instance.Config.SleepDurationSeconds,
                false,
                0f);
        }
    }

    // --- From LethalActionReborn (Venomaus, MIT): forget the dart count once the citizen wakes. ---
    [HarmonyPatch(typeof(NewAIController), nameof(NewAIController.SetKO))]
    internal class NewAIController_SetKO
    {
        [HarmonyPostfix]
        internal static void Postfix(NewAIController __instance, bool val)
        {
            if (!val && __instance.human != null)
            {
                Citizen_RecieveDamage.DartsTaken.Remove(__instance.human.humanID);
            }
        }
    }
}
