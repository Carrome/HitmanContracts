using SOD.Common.BepInEx.Configuration;

namespace TranquilizerPistol;

public interface IConfigBindings
{
    [Binding(1, "How many darts a citizen must take before falling asleep.", "Tranquilizer.DartsRequiredToSleep")]
    int DartsRequiredToSleep { get; set; }

    [Binding(120f, "How long (in seconds) a tranquilized citizen stays asleep. Needs in-game testing to confirm the unit the game uses for forced KO duration.", "Tranquilizer.SleepDurationSeconds")]
    float SleepDurationSeconds { get; set; }

    [Binding(0.9f, "Accuracy of the pistol from 0.0 to 1.0 (1.0 = perfectly accurate). Set to -1 to use the game's own value.", "Weapon.Accuracy")]
    float Accuracy { get; set; }

    [Binding(1.0f, "Delay between shots, as a factor on top of the game's fire delay.", "Weapon.DelayBetweenShotsFactor")]
    float DelayBetweenShotsFactor { get; set; }

    [Binding(0.3f, "Camera kick per shot. Set to 0 to disable recoil completely.", "Weapon.RecoilAmplitude")]
    float RecoilAmplitude { get; set; }

    [Binding(0.2f, "How much the camera zooms in while aiming (0.0 to 1.0).", "Weapon.ZoomInOnAimPct")]
    float ZoomInOnAimPct { get; set; }

    [Binding(false, "If true, shooting a citizen who sees you still gives you the illegal status for a few seconds. If false, the pistol is fully legal to use.", "Stealth.IllegalWhenSeen")]
    bool IllegalWhenSeen { get; set; }

    [Binding(3.0f, "Seconds of illegal status after a shot, when Stealth.IllegalWhenSeen is true.", "Stealth.IllegalStatusDurationOnHit")]
    float IllegalStatusDurationOnHit { get; set; }

    [Binding(false, "If true, shots alert nearby citizens like a normal gunshot. Default is false (silent).", "Stealth.AlertSurroundingOnHit")]
    bool AlertSurroundingOnHit { get; set; }

    [Binding(false, "Testing: if true, puts the pistol in your inventory. Save as false before setting it to true again.", "Debug.GiveWeapon")]
    bool GiveWeapon { get; set; }
}
