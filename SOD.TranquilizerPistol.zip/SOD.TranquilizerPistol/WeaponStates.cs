namespace TranquilizerPistol;

// Adapted from Guns by Spyraxi (ReveredRedHood), MIT License.
public enum WeaponPrimaryState
{
    NotAiming,
    Aiming,
    Firing,
}

public enum WeaponSecondaryState
{
    NotEquipped,
    NotAiming,
    Aiming,
}
