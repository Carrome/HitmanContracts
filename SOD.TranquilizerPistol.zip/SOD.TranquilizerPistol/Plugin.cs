using System;
using System.Collections;
using System.Linq;
using BepInEx;
using BepInEx.Configuration;
using SOD.Common;
using SOD.Common.BepInEx;
using SOD.Common.Extensions;
using SOD.Common.Helpers;
using UnityEngine;
using UniverseLib;

namespace TranquilizerPistol;

/// <summary>
/// Silenced tranquilizer pistol for Shadows of Doubt.
///
/// Firing/aiming logic adapted from "Guns" by Spyraxi (ReveredRedHood), MIT License.
/// Knocked-out state handling pattern adapted from "SODLethalActionReborn" by Venomaus, MIT License.
/// See THIRD_PARTY_NOTICES.md.
/// </summary>
[BepInPlugin(PLUGIN_GUID, PLUGIN_NAME, PLUGIN_VERSION)]
[BepInProcess("Shadows of Doubt.exe")]
[BepInDependency(SOD.Common.Plugin.PLUGIN_GUID, BepInDependency.DependencyFlags.HardDependency)]
// This mod includes its own copy of the shooting code, so it must not run next to the original Guns mod.
[BepInIncompatibility("Guns")]
public class Plugin : PluginController<Plugin, IConfigBindings>
{
    public const string PLUGIN_GUID = "TranquilizerPistol";
    public const string PLUGIN_NAME = "TranquilizerPistol";
    public const string PLUGIN_VERSION = "0.1.0";

    // The game's silenced pistol is reused as the tranquilizer pistol.
    private const string PISTOL_PRESET_NAME = "SemiAutomaticPistolSilenced";
    private static readonly Vector3 PistolRotation = new Vector3(0f, -90f, 0f);
    private static readonly Vector3 RecoilPattern = new Vector3(1.0f, 1.0f, 0.5f).normalized;

    private const float RECOIL_SPEED = 1.0f;
    private const float EJECT_POINT_PROJECTION_FACTOR = 6.0f;
    private const float TIMER_DURATION = 0.25f;
    private const string ACTION_DDS_DICTIONARY_NAME = "ui.interaction";
    private const string ACTION_NAME_AIM = "Aim";
    private const string ACTION_NAME_ATTACK = "Attack";
    private const string ACTION_NAME_FIRE = "Fire";
    private const string ACTION_NAME_THROW = "Throw";
    private const string PRIMARY = "Primary";
    private const string SECONDARY = "Secondary";

    private InteractablePreset pistolPreset;
    private bool weaponOnCooldown;
    private bool isFireHeldDown;
    private bool isGamePaused;
    private bool inGameSetupCompleted;
    private Coroutine cameraFovTweenCoroutine;

    private WeaponPrimaryState currentWeaponPrimaryState;
    public WeaponPrimaryState CurrentWeaponPrimaryState
    {
        get => currentWeaponPrimaryState;
        internal set
        {
            currentWeaponPrimaryState = value;
            SetPrimaryActionFire(value == WeaponPrimaryState.Aiming || value == WeaponPrimaryState.Firing);
        }
    }

    private WeaponSecondaryState currentWeaponSecondaryState;
    public WeaponSecondaryState CurrentWeaponSecondaryState
    {
        get => currentWeaponSecondaryState;
        internal set
        {
            currentWeaponSecondaryState = value;
            SetSecondaryActionAim(value == WeaponSecondaryState.NotAiming || value == WeaponSecondaryState.Aiming);
        }
    }

    internal InteractablePreset CurrentInteractablePresetHeld =>
        BioScreenController.Instance.selectedSlot?.GetInteractable()?.preset;

    public bool IsPlayerHoldingPistol() =>
        pistolPreset != null
        && CurrentInteractablePresetHeld != null
        && CurrentInteractablePresetHeld.presetName == PISTOL_PRESET_NAME;

    public override void Load()
    {
        Harmony.PatchAll();
        Log.LogInfo($"Plugin {PLUGIN_GUID} is loaded and patched!");

        Lib.SaveGame.OnAfterLoad += OnAfterLoad;
        Lib.SaveGame.OnAfterNewGame += OnAfterNewGame;
        Lib.Time.OnGamePaused += OnGamePaused;
        Lib.Time.OnGameResumed += OnGameResumed;
        Lib.InputDetection.OnButtonStateChanged += OnButtonStateChanged;

        ConfigFile.SettingChanged += ProcessSettingChange;
    }

    public override bool Unload()
    {
        Harmony?.UnpatchSelf();

        Lib.SaveGame.OnAfterLoad -= OnAfterLoad;
        Lib.SaveGame.OnAfterNewGame -= OnAfterNewGame;
        Lib.Time.OnGamePaused -= OnGamePaused;
        Lib.Time.OnGameResumed -= OnGameResumed;
        Lib.InputDetection.OnButtonStateChanged -= OnButtonStateChanged;

        ConfigFile.SettingChanged -= ProcessSettingChange;

        return base.Unload();
    }

    // ---------------------------------------------------------------- setup

    private void OnAfterNewGame(object sender, EventArgs e) => InGameSetup();

    private void OnAfterLoad(object sender, SaveGameArgs e) => InGameSetup();

    private void InGameSetup()
    {
        currentWeaponPrimaryState = WeaponPrimaryState.NotAiming;
        currentWeaponSecondaryState = WeaponSecondaryState.NotEquipped;
        isFireHeldDown = false;
        weaponOnCooldown = false;
        Patches.Citizen_RecieveDamage.DartsTaken.Clear();

        // "Aim" and "Fire" labels for the interaction prompts.
        Lib.DdsStrings.AddOrUpdateEntries(
            ACTION_DDS_DICTIONARY_NAME,
            (ACTION_NAME_AIM, ACTION_NAME_AIM),
            (ACTION_NAME_FIRE, ACTION_NAME_FIRE));

        pistolPreset = Helpers.GetPresetInstances<InteractablePreset>()
            .FirstOrDefault(x => x.presetName == PISTOL_PRESET_NAME);

        if (pistolPreset == null)
        {
            Log.LogError($"Could not find the item preset '{PISTOL_PRESET_NAME}'. The mod will stay inactive.");
            return;
        }

        // Make the pistol point forward.
        pistolPreset.fpsItemOffset = Vector3.zero;
        pistolPreset.fpsItemRotation = PistolRotation;

        inGameSetupCompleted = true;
    }

    private void ProcessSettingChange(object sender, SettingChangedEventArgs e)
    {
        if (!inGameSetupCompleted) return;

        if (Config.GiveWeapon)
        {
            pistolPreset.SpawnIntoInventory();
        }
    }

    // ---------------------------------------------------------------- input

    private void OnButtonStateChanged(object sender, InputDetectionEventArgs eventArgs)
    {
        if (!inGameSetupCompleted) return;
        if (eventArgs.ActionName != PRIMARY && eventArgs.ActionName != SECONDARY) return;

        if (!IsPlayerHoldingPistol())
        {
            CurrentWeaponSecondaryState = WeaponSecondaryState.NotEquipped;
            RestartCameraAimModeCoroutine(false);
            return;
        }

        if (eventArgs.ActionName == PRIMARY)
        {
            isFireHeldDown = eventArgs.IsDown;
        }

        switch (CurrentWeaponSecondaryState)
        {
            case WeaponSecondaryState.NotAiming:
                if (eventArgs.ActionName == SECONDARY && eventArgs.IsDown)
                {
                    CurrentWeaponSecondaryState = WeaponSecondaryState.Aiming;
                    CurrentWeaponPrimaryState = WeaponPrimaryState.Aiming;
                    RestartCameraAimModeCoroutine(true);
                }
                break;

            case WeaponSecondaryState.Aiming:
                if (eventArgs.ActionName == SECONDARY && !eventArgs.IsDown)
                {
                    CurrentWeaponSecondaryState = WeaponSecondaryState.NotAiming;
                    CurrentWeaponPrimaryState = WeaponPrimaryState.NotAiming;
                    RestartCameraAimModeCoroutine(false);
                }
                else if (isFireHeldDown)
                {
                    FireWeapon();
                }
                break;
        }
    }

    // ---------------------------------------------------------------- firing

    public void FireWeapon()
    {
        if (!inGameSetupCompleted || isGamePaused || weaponOnCooldown) return;
        if (!IsPlayerHoldingPistol()) return;
        if (CurrentWeaponSecondaryState != WeaponSecondaryState.Aiming
            || CurrentWeaponPrimaryState != WeaponPrimaryState.Aiming) return;

        CurrentWeaponPrimaryState = WeaponPrimaryState.Firing;

        var weapon = pistolPreset.weapon;

        // Largely taken from NewAIController.RecalculateWeaponStats (via Guns).
        var weaponRangeMax = weapon.GetAttackValue(MurderWeaponPreset.AttackValue.range, Player.Instance);
        var weaponRefire = weapon.GetAttackValue(MurderWeaponPreset.AttackValue.fireDelay, Player.Instance)
                           * Config.DelayBetweenShotsFactor;
        var weaponAccuracy = Config.Accuracy < 0f
            ? weapon.GetAttackValue(MurderWeaponPreset.AttackValue.accuracy, Player.Instance)
            : Config.Accuracy;
        // The real damage is discarded in Patches.Citizen_RecieveDamage; it just has to be a normal shot.
        var weaponDamage = weapon.GetAttackValue(MurderWeaponPreset.AttackValue.damage, Player.Instance);

        // Largely taken from Game.ShootFromPlayer (via Guns).
        var muzzlePoint = FirstPersonItemController.Instance.rightHandObjectParent.TransformPoint(weapon.itemRightLocalPos);
        var ejectPoint = FirstPersonItemController.Instance.rightHandObjectParent.TransformPoint(
            weapon.itemRightLocalPos + Vector3.back * EJECT_POINT_PROJECTION_FACTOR);
        var aimPoint = CameraController.Instance.cam.transform.position;
        var aimForwardPoint = CameraController.Instance.cam.transform.TransformPoint(Vector3.forward);

        // A silenced dart gun has no visible muzzle flash.
        var muzzleFlash = weapon.muzzleFlash;
        weapon.muzzleFlash = null;
        Toolbox.Instance.Shoot(Player.Instance, aimPoint, aimForwardPoint, weaponRangeMax, weaponAccuracy,
            weaponDamage, weapon, false, ejectPoint, false, true);
        weapon.muzzleFlash = muzzleFlash;

        if (Config.RecoilAmplitude > float.Epsilon)
        {
            var recoilVector = new Vector3(
                Toolbox.Instance.Rand(-1.0f, 1.0f),
                Toolbox.Instance.Rand(-1.0f, 1.0f),
                Toolbox.Instance.Rand(-1.0f, 1.0f));
            recoilVector.Scale(RecoilPattern);
            Player.Instance.fps.JoltCamera(recoilVector, Config.RecoilAmplitude, speed: RECOIL_SPEED);
        }

        ApplyPlayerIllegalActionStatus();

        // Cooldown between shots.
        weaponOnCooldown = true;
        CurrentWeaponPrimaryState = WeaponPrimaryState.Aiming;
        RuntimeHelper.StartCoroutine(InGameTimer(weaponRefire, () => weaponOnCooldown = false));
    }

    private void ApplyPlayerIllegalActionStatus()
    {
        if (!Config.IllegalWhenSeen
            || Player.Instance.isHome
            || (!Player.Instance.isSeenByOthers && !Helpers.IsPlayerHeardByOthers()))
        {
            Lib.PlayerStatus.RemoveIllegalStatusModifier(PLUGIN_GUID);
            return;
        }

        Lib.PlayerStatus.SetIllegalStatusModifier(
            PLUGIN_GUID, TimeSpan.FromSeconds(Config.IllegalStatusDurationOnHit), true);
    }

    // ---------------------------------------------------------------- camera

    private void RestartCameraAimModeCoroutine(bool enter)
    {
        if (cameraFovTweenCoroutine != null)
        {
            RuntimeHelper.StopCoroutine(cameraFovTweenCoroutine);
        }

        cameraFovTweenCoroutine = RuntimeHelper.StartCoroutine(
            InGameTween(TIMER_DURATION, enter ? AdjustCameraEnterAimMode : AdjustCameraExitAimMode));
    }

    private void AdjustCameraEnterAimMode(float progressPct)
    {
        if (!IsPlayerHoldingPistol())
        {
            RestartCameraAimModeCoroutine(false);
            return;
        }

        var currentFov = CameraController.Instance.cam.fieldOfView;
        var targetFov = Game.Instance.fov * (1.0f - Config.ZoomInOnAimPct);
        CameraController.Instance.cam.fieldOfView = currentFov - (currentFov - targetFov) * progressPct;
    }

    private void AdjustCameraExitAimMode(float progressPct)
    {
        var currentFov = CameraController.Instance.cam.fieldOfView;
        CameraController.Instance.cam.fieldOfView = currentFov - (currentFov - Game.Instance.fov) * progressPct;
    }

    // ---------------------------------------------------------------- prompts (Attack -> Fire, Throw -> Aim)

    private void SetPrimaryActionFire(bool showAsFire)
    {
        if (!inGameSetupCompleted || CurrentInteractablePresetHeld == null) return;

        FirstPersonItem.FPSInteractionAction attackFpsAction;
        try
        {
            attackFpsAction = CurrentInteractablePresetHeld.fpsItem.actions.ToList()
                .First(x => x.action.presetName == "FPSPunch");
        }
        catch
        {
            return;
        }

        attackFpsAction.interactionName = showAsFire ? ACTION_NAME_FIRE : ACTION_NAME_ATTACK;
        attackFpsAction.useCameraJolt = !showAsFire;
        attackFpsAction.mainSpecialAction = showAsFire
            ? FirstPersonItem.SpecialAction.none
            : FirstPersonItem.SpecialAction.punch;
        InteractionController.Instance.UpdateInteractionText();
    }

    private void SetSecondaryActionAim(bool showAsAim)
    {
        if (!inGameSetupCompleted || CurrentInteractablePresetHeld == null) return;

        FirstPersonItem.FPSInteractionAction throwFpsAction;
        try
        {
            throwFpsAction = CurrentInteractablePresetHeld.fpsItem.actions.ToList()
                .First(x => x.action.presetName == "FPSThrow");
        }
        catch
        {
            return;
        }

        throwFpsAction.interactionName = showAsAim ? ACTION_NAME_AIM : ACTION_NAME_THROW;
        throwFpsAction.action.throwObjectsAtTarget = !showAsAim;
        throwFpsAction.mainSpecialAction = showAsAim
            ? FirstPersonItem.SpecialAction.none
            : FirstPersonItem.SpecialAction.attack;
        InteractionController.Instance.UpdateInteractionText();
    }

    // ---------------------------------------------------------------- timers / pause

    private IEnumerator InGameTimer(float durationSec, Action actionOnCompletion)
    {
        var timePassed = 0.0f;
        while (timePassed < durationSec)
        {
            yield return new WaitForEndOfFrame();
            if (isGamePaused) continue;
            timePassed += UnityEngine.Time.deltaTime;
        }
        actionOnCompletion();
    }

    private IEnumerator InGameTween(float durationSec, Action<float> actionPerTick)
    {
        var timePassed = 0.0f;
        while (timePassed < durationSec)
        {
            yield return new WaitForEndOfFrame();
            if (isGamePaused) continue;
            timePassed += UnityEngine.Time.deltaTime;
            actionPerTick(timePassed / durationSec);
        }
    }

    private void OnGameResumed(object sender, EventArgs e) => isGamePaused = false;

    private void OnGamePaused(object sender, EventArgs e) => isGamePaused = true;
}
